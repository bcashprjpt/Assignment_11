#importing (iimim)
from flask import Flask, render_template, request

#interaction
app = Flask(__name__)

#mapping
@app.route('/')
#input
def home():
    return render_template('home.html')

@app.route('/register')
#input
def register():
    return render_template('register.html')

@app.route('/link')
#input
def link():
    return render_template('link.html')

@app.route('/confirm',methods = ['POST','GET'])
#input
def confirm():

    f_name = request.form.get('f_name')
    l_name = request.form.get('l_name')
    email  = request.form.get('email')
    adres1  = request.form.get('address1')
    adres2  = request.form.get('address2')
    state =  request.form.get('state')
    city = request.form.get('city')
    pin =  request.form.get('pin')
    return render_template('confirm.html',
                           f_name = f_name, l_name = l_name, email = email, adres1 = adres1, adres2 = adres2, state = state, city = city, pin = pin)

#main
if __name__ == '__main__':
    app.run(debug=True)

